import subprocess
import pyttsx3 # type: ignore
import speech_recognition as sr # type: ignore
import pyautogui # type: ignore
import datetime
import os
import webbrowser
import pywhatkit # type: ignore
import openai # type: ignore

# Set up OpenAI API key
openai.api_key = "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"

# Initialize the text-to-speech engine
engine = pyttsx3.init()

# Retrieve available voices
voices = engine.getProperty('voices')

# Ensure there are voices to choose from
if len(voices) > 1:
    # Set to the second available voice (index 1)
    engine.setProperty('voice', voices[1].id)
    print(f"Voice set to: {voices[1].name}")
else:
    print("Only one voice available. Using the default voice.")
# Function to search on Google
def search_google(query):
    """Search a query on Google."""
    try:
        speak(f"Searching for {query} on Google.")
        webbrowser.open(f"https://www.google.com/search?q={query}")
    except Exception as e:
        speak("Sorry, I couldn't search on Google.")
        print(f"Error: {e}")



# Function to speak
def speak(text):
    """Speak the given text."""
    engine.say(text)
    engine.runAndWait()

def initialize_voice(gender="female", rate=150, volume=1.0):
    """Initialize the voice properties."""
    voices = engine.getProperty('voices')
    for index, voice in enumerate(voices):
        print(f"Voice {index}: {voice.name}")

    # Set desired voice based on gender preference
    for voice in voices:
        if gender.lower() in voice.name.lower():
            engine.setProperty('voice', voice.id)
            print(f"Voice set to: {voice.name}")
            break
    else:
        print("Desired voice not found. Using default voice.")

    # Set speech rate and volume
    engine.setProperty('rate', rate)
    engine.setProperty('volume', volume)

def take_screenshot():
    """Take a screenshot and save it."""
    try:
        screenshots_dir = "screenshots"
        if not os.path.exists(screenshots_dir):
            os.makedirs(screenshots_dir)

        timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        screenshot_path = os.path.join(screenshots_dir, f"screenshot_{timestamp}.png")

        screenshot = pyautogui.screenshot()
        screenshot.save(screenshot_path)
        speak("Screenshot taken successfully.")
        print(f"Screenshot saved at {screenshot_path}")
    except Exception as e:
        speak("Sorry, I couldn't take a screenshot.")
        print(f"Error: {e}")

def open_website(command):
    """Open a website based on the user's command."""
    try:
        if "open" in command:
            # Extract the website name or domain from the command
            website = command.replace("open ", "").strip()
            # Add the appropriate prefix if not already present
            if not website.startswith("http://") and not website.startswith("https://"):
                if "." not in website:  # Handle cases where the user doesn't provide a domain
                    website += ".com"  # Default to ".com"
                website = "https://www." + website
            webbrowser.open(website)
            speak(f"Opening {website}")
        else:
            speak("I couldn't understand which website to open.")
    except Exception as e:
        speak("Sorry, I couldn't open the website.")
        print(f"Error: {e}")

def command_chatgpt(prompt):
    """Send a prompt to ChatGPT and return the response."""
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
        )
        answer = response['choices'][0]['message']['content']
        speak("Here is the response from ChatGPT.")
        print("ChatGPT:", answer)
    except Exception as e:
        speak("Sorry, I couldn't process your request to ChatGPT.")
        print(f"Error: {e}")

def play_music_on_youtube(command):
    """Search for and play music on YouTube."""
    try:
        song = command.replace("play", "").strip()
        pywhatkit.playonyt(song)
        speak(f"Playing {song} on YouTube.")
    except Exception as e:
        speak("Sorry, I couldn't play the music on YouTube.")
        print(f"Error: {e}")

def listen_command():
    """Listen to the user's command using speech recognition."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak(" i am Redy talk to You  .")
        print("Listening.......")
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=10)
            command = recognizer.recognize_google(audio)
            print(f"You said: {command}")
            return command.lower()
        except sr.UnknownValueError:
            speak("Sorry, I didn't understand that.")
            return None
        except sr.RequestError as e:
            speak("Sorry, my speech recognition service is not working.")
            print(f"Error: {e}")
            return None
        except Exception as e:
            speak("An error occurred while listening.")
            print(f"Error: {e}")
            return None
#caht gpt
def solve_problem(command):
    """Identify a problem-solving intent and use ChatGPT."""
    try:
        # Check for specific problem-solving keywords
        if "solve" in command or "calculate" in command or "explain" in command:
            speak("Let me think about it.")
            response = openai.ChatCompletion.create(
                model="gpt-4",
                messages=[{"role": "user", "content": command}]
            )
            answer = response['choices'][0]['message']['content']
            speak(f"Here is the solution: {answer}")
            print("Solution:", answer)
        else:
            speak("I couldn't identify a problem to solve.")
    except Exception as e:
        speak("An error occurred while solving the problem.")
        print(f"Error: {e}")

# Command to open WhatsApp
def open_whatsapp():
    """Open WhatsApp (web version or app)."""
    try:
        speak("Opening WhatsApp.")
        # For WhatsApp Web
        webbrowser.open("https://web.whatsapp.com")
        # Alternatively, for the desktop app:
        #subprocess.Popen(["C:\\Path\\to\\WhatsApp.exe"])

    except Exception as e:
        speak("Sorry, I couldn't open WhatsApp.")
        print(f"Error: {e}")
# Open Webcam
        def open_webcam():
            """Open the webcam application."""
            try:
                speak("Opening the webcam.")
                # You can use the default camera app, or any other app that you have installed
                subprocess.Popen("start microsoft.windows.camera:")  # This opens the built-in Camera app
            except Exception as e:
                speak("Sorry, I couldn't open the webcam.")
                print(f"Error: {e}")

# Command to execute system commands
                def execute_system_command(command):
                    """Execute any system command."""
                    try:
                        speak(f"Executing system command: {command}.")
                        subprocess.run(command, shell=True)
                    except Exception as e:
                        speak("Sorry, I couldn't execute the system command.")
                        print(f"Error: {e}")

 # Command to open a folder
    def open_folder(folder_path):
        """Open a specific folder."""
        try:
            speak(f"Opening folder {folder_path}.")
            os.startfile(folder_path)  # Opens a folder in the file explorer
        except Exception as e:
            speak("Sorry, I couldn't open the folder.")
            print(f"Error: {e}")

def execute_command(command):
    """Execute the user's command."""
    if command:
        if "screenshot" in command:
            take_screenshot()
        elif "time" in command:
            current_time = datetime.datetime.now().strftime("%I:%M %p")
            speak(f"The current time is {current_time}")
            print(f"The current time is {current_time}")
        elif "date" in command:
            current_date = datetime.datetime.now().strftime("%A, %B %d, %Y")
            speak(f"Today's date is {current_date}")
            print(f"Today's date is {current_date}")
        elif "exit" in command or "quit" in command or "bye" in command:
            speak("Goodbye!Love You Sweet Heart!!!")
            exit()
        elif "open" in command:
            open_website(command)
        elif "chat gpt" in command:
            prompt = command.replace("chat gpt", "").strip()
            command_chatgpt(prompt)
        elif "play" in command and "youtube" in command:
            play_music_on_youtube(command)
        else:
            speak("I'm not sure how to respond to that.")
    else:
        speak("I didn't hear any command.")
# Function to handle sleep command
def handle_sleep():
    """Handle the 'sleep' command to exit the program."""
    speak("Goodbye, I am going to sleep now.")
    exit()

def main():
    """Main function to run the JARVIS AI."""
    initialize_voice(gender="female", rate=150, volume=1.0)
    speak("Hello, I am lili. How can I help you?")
    while True:
        command = listen_command()
        execute_command(command)

if __name__ == "__main__":
    main()
