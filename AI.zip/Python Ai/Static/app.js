const btn = document.querySelector('.talk');
const content = document.querySelector('.content');

// Initialize Speech Recognition
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();

recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript; // Capture the user's command
    content.textContent = `You said: "${transcript}"`;

    // Send the command to the Flask backend
    fetch('/process', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: transcript }) // Send command as JSON
    })
        .then(response => response.json())
        .then(data => {
            const reply = data.response; // Get the response from the backend
            content.textContent = reply;
            speak(reply); // Use text-to-speech to speak the reply
        })
        .catch(error => {
            console.error("Error communicating with the backend:", error);
            content.textContent = "An error occurred.";
        });
};

// Text-to-Speech
function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;
    window.speechSynthesis.speak(utterance);
}

// Start recognition on button click
btn.addEventListener('click', () => {
    content.textContent = "Listening...";
    recognition.start();
});
