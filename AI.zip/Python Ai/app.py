from flask import Flask, request, jsonify
from JARVIS import execute_command  # Import the function from your JARVIS.py

app = Flask(__name__)

@app.route("/")
def index():
    """Serve the HTML frontend."""
    return app.send_static_file("index.html")

@app.route("/process", methods=["POST"])
def process_command():
    """Process commands sent from the frontend."""
    data = request.get_json()  # Get JSON data from the POST request
    command = data.get("command", "")  # Extract the 'command'

    if command:
        # Process the command using JARVIS logic
        response = execute_command(command)
        return jsonify({"response": response})
    else:
        return jsonify({"response": "No command received."}), 400

if __name__ == "__main__":
    app.run(debug=True)
